<footer class="footer">
    <div class="footer-text">
        <p>All rights reserved Copyright &#169; 2023-24 Design &amp; Developed By <a href="javascript:void(0)">Aurum Edtech</a> </p>
    </div>
</footer>


<!-- js -->
<script src="../js/jquery-3.7.1.min.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
<script src="../js/main.js"></script>